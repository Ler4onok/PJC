# LCS (Longest Common Subsequence)

## Options
My program has 3 options to choose. 

### 1st option 
-c [word 1][word 2] -- find the LCS of 2 words.

Input example: -c hello helicopter
Output example: LCS of the words -hello- and -helicopter- is 4.

### 2nd option
-c [word 1][word 2][word 3] -- find the LCS of 3 words.

Input example: -c hello helicopter header
Output example: LCS of the words -hello-, -helicopter- and -header- is 2.


### 3rd option
-f [file.txt][word] -- find the word from the file.txt which has the biggest LCS with the written word.

Input example: -f words.txt alien
Output example: The word -listen- has the biggest LCS (4) with the given word -alien-.